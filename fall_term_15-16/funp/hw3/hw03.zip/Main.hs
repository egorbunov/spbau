module Main where
import qualified HW03P1 as P1
import qualified HW03P2 as P2
import qualified HW03P3 as P3

main = P1.main >> P2.main >> P3.main
