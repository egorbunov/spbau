#! /bin/bash

function is_user_online {
	online_status_node=$(wget -q -O - http://vk.com/$1 | grep -o "<[^<]*profile_online_lv[^>]*>")
	if [[ $online_status_node == *"style=\"display: none;\""* ]]
	then
		echo false
	else
		echo true
	fi
}

vk_user=ankuzik # put here vk user id (with id prefix in case of numeric value)
sleep_t=60s

status=$(is_user_online $vk_user)

if [ $status == false ]; then
	echo $vk_user "is OFFLINE now" | wall
else
	echo $vk_user "is ONLINE now" | wall
fi

while [ true ]; do
	cur_status=$(is_user_online $vk_user)

	if [ $cur_status != $status ]; then 
		status=$cur_status

		if [ $cur_status == false ]; then
			echo $vk_user "has gone OFFLINE" | wall
		else
			echo $vk_user "is back ONLINE" | wall
		fi
	fi

	sleep $sleep_t
done
