#! /bin/sh
pgrep $1 -l
