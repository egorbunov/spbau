#! /bin/bash
factor < 3.in > 3.out